# Clothing Store

v1. Versión sólo con el CRUD

![1768382056851](image/README/1768382056851.png)
