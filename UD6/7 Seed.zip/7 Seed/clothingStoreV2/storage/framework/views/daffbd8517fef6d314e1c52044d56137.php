<?php $__env->startSection('title', 'Editar Artículo'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h1>Editar Artículo</h1>
        <a href="<?php echo e(route('clothing-items.index')); ?>" class="btn btn-secondary">🔙 Volver al Listado</a>
    </div>

    <form method="POST" action="<?php echo e(route('clothing-items.update', $clothingItem->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-grid">
            <div class="form-group">
                <label for="name">📝 Nombre</label>
                <input type="text" name="name" id="name" value="<?php echo e(old('name', $clothingItem->name)); ?>" required>
            </div>
            <div class="form-group">
                <label for="size">📏 Talla</label>
                <input type="text" name="size" id="size" value="<?php echo e(old('size', $clothingItem->size)); ?>" required>
            </div>
            <div class="form-group">
                <label for="price">💰 Precio ($)</label>
                <input type="text" name="price" id="price" value="<?php echo e(old('price', $clothingItem->price)); ?>" required>
            </div>
            <div class="form-group">
                <label for="color">🎨 Color</label>
                <input type="text" name="color" id="color" value="<?php echo e(old('color', $clothingItem->color)); ?>" required>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">✅ Actualizar</button>
            <a href="<?php echo e(route('clothing-items.index')); ?>" class="btn btn-danger">❌ Cancelar</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\DWES_FranciscoPerez\UD6\7 Seed\clothingStoreV2\resources\views/clothing-items/edit.blade.php ENDPATH**/ ?>