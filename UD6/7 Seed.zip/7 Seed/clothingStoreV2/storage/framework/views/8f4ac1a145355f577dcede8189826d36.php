<?php $__env->startSection('title', 'Listado de Artículos'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h1>Clothing Items</h1>
        <a href="<?php echo e(route('clothing-items.create')); ?>" class="btn btn-primary">➕ Añadir Artículo</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Talla</th>
                <th>Precio</th>
                <th>Color</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->size); ?></td>
                <td class="price">$<?php echo e(number_format($item->price, 2)); ?></td>
                <td><span class="color-badge"><?php echo e($item->color); ?></span></td>
                <td>
                    <div class="actions">
                        <a href="<?php echo e(route('clothing-items.show', $item)); ?>" class="btn btn-info btn-sm">👁️ Ver</a>
                        <a href="<?php echo e(route('clothing-items.edit', $item)); ?>" class="btn btn-warning btn-sm">✏️ Editar</a>
                        <form method="POST" action="<?php echo e(route('clothing-items.destroy', $item)); ?>" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar este artículo?')">🗑️ Eliminar</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" style="text-align: center; padding: 40px;">No hay artículos disponibles 😢</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\DWES_FranciscoPerez\UD6\7 Seed\clothingStoreV2\resources\views/clothing-items/index.blade.php ENDPATH**/ ?>