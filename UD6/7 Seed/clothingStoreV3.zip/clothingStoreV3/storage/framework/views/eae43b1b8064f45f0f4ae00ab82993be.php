<h1>Clothing Item Details</h1>

<p><strong>Name:</strong> <?php echo e($clothingItem->name); ?></p>
<p><strong>Size:</strong> <?php echo e($clothingItem->size); ?></p>
<p><strong>Price:</strong> $<?php echo e(number_format($clothingItem->price, 2)); ?></p>
<p><strong>Color:</strong> <?php echo e($clothingItem->color); ?></p>

<a href="<?php echo e(route('clothing-items.edit', $clothingItem->id)); ?>">Edit</a>

<form method="POST" action="<?php echo e(route('clothing-items.destroy', $clothingItem->id)); ?>" style="display:inline;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" onclick="return confirm('Are you sure you want to delete this item?')">Delete</button>
</form>

<br><br>
<a href="<?php echo e(route('clothing-items.index')); ?>">Back to List</a>
<?php /**PATH C:\xampp\htdocs\DWES_FranciscoPerez\UD6\7 Seed\clothingStore\resources\views/clothing-items/show.blade.php ENDPATH**/ ?>