
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>CRUDs</title>
  <link rel="stylesheet" href="<?php echo e(url('css/app.css')); ?>">
</head>
<body>
  <nav>
    <a href="<?php echo e(url('/')); ?>">Home</a> |
    <a href="<?php echo e(route('users.index')); ?>">Users</a> |
    <a href="<?php echo e(route('clothing-items.index')); ?>">Clothing</a>
  </nav>
  <main><?php echo $__env->yieldContent('content'); ?></main>
</body>
</html><?php /**PATH C:\xampp\htdocs\DWES_FranciscoPerez\UD6\7 Seed\clothingStoreV3\resources\views/layouts/app.blade.php ENDPATH**/ ?>