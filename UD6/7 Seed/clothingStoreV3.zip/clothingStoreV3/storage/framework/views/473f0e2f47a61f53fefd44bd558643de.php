

<?php $__env->startSection('content'); ?>
  <h1>Welcome</h1>
  <ul>
    <li><a href="<?php echo e(route('users.index')); ?>">Go to Users CRUD</a></li>
    <li><a href="<?php echo e(route('clothing-items.index')); ?>">Go to Clothing CRUD</a></li>
  </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\DWES_FranciscoPerez\UD6\7 Seed\clothingStoreV3\resources\views/home.blade.php ENDPATH**/ ?>