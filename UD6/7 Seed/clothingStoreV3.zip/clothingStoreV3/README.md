# Clothing Store

En esta primera version hemos creado las databases con los seeders

![1768383891369](image/README/1768383891369.png)
